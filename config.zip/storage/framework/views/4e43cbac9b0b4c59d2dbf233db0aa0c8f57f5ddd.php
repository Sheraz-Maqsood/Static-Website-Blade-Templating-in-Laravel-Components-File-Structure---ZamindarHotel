<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startPush('cs'); ?>
     
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->startPush('preload'); ?>

<?php $__env->stopPush(); ?>

<!-- Header Banner -->
<div class="banner-header section-padding valign bg-img bg-fixed" data-overlay-dark="4" data-background="img/slider/10.jpg">
    <div class="container">
        <div class="row">
            <div class="col-md-12 caption mt-90">
                <h5>Luxury Hotel</h5>
                <h1>About Us</h1>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.components.about-para-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.components.extra-services-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.components.facilities-hotel-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.components.team-about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.components.testimonials-guests-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
    <script>

    </script>

   
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARVEL PROJECTS\Static Website Blade Templating in Laravel Components File Structure - ZamindarHotel\resources\views/about.blade.php ENDPATH**/ ?>