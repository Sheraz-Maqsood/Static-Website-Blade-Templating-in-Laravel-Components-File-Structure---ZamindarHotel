<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startPush('cs'); ?>
     
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->startPush('preload'); ?>

<?php $__env->stopPush(); ?>

<!-- Header Banner -->
<div class="banner-header section-padding valign bg-img bg-fixed" data-overlay-dark="4" data-background="img/slider/1.jpg">
    <div class="container">
        <div class="row">
            <div class="col-md-12 caption mt-90">
                <h5>Luxury Hotel</h5>
                <h1>About Us</h1>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.components.about-para-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.components.extra-services-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.components.facilities-hotel-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Team -->
<section class="team section-padding bg-darkblack">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-subtitle">Professionals</div>
                <div class="section-title">Meet The Team</div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 owl-carousel owl-theme">
                <div class="item">
                    <div class="img"> <img src="img/team/4.jpg" alt=""> </div>
                    <div class="info">
                        <h6>Valentina Karla</h6>
                        <p>General Manager</p>
                        <div class="social valign">
                            <div class="full-width">
                               <a href="#"><i class="ti-instagram"></i></a>
                               <a href="#"><i class="ti-twitter"></i></a>
                               <a href="#"><i class="ti-facebook"></i></a>
                               <a href="#"><i class="ti-pinterest"></i></a>
                               <p>valentina@hotel.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img">
                    <img src="img/team/1.jpg" alt=""> </div>
                    <div class="info">
                        <h6>Micheal White</h6>
                        <p>Guest Service Department</p>
                        <div class="social valign">
                            <div class="full-width">
                                <a href="#"><i class="ti-instagram"></i></a>
                                <a href="#"><i class="ti-twitter"></i></a>
                                <a href="#"><i class="ti-facebook"></i></a>
                                <a href="#"><i class="ti-pinterest"></i></a>
                                <p>micheal@hotel.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img"> <img src="img/team/2.jpg" alt=""> </div>
                    <div class="info">
                        <h6>Olivia Martin</h6>
                        <p>Reservations Manager</p>
                        <div class="social valign">
                            <div class="social valign">
                                <div class="full-width">
                                   <a href="#"><i class="ti-instagram"></i></a>
                                   <a href="#"><i class="ti-twitter"></i></a>
                                   <a href="#"><i class="ti-facebook"></i></a>
                                   <a href="#"><i class="ti-pinterest"></i></a>
                                   <p>olivia@hotel.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img"> <img src="img/team/5.jpg" alt=""> </div>
                    <div class="info">
                        <h6>Mariana Dana</h6>
                        <p>F&B Manager</p>
                        <div class="social valign">
                            <div class="full-width">
                               <a href="#"><i class="ti-instagram"></i></a>
                               <a href="#"><i class="ti-twitter"></i></a>
                               <a href="#"><i class="ti-facebook"></i></a>
                               <a href="#"><i class="ti-pinterest"></i></a>
                               <p>mariana@hotel.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img"> <img src="img/team/3.jpg" alt=""> </div>
                    <div class="info">
                        <h6>Enrico Brown</h6>
                        <p>Head Chef</p>
                        <div class="social valign">
                            <div class="full-width">
                               <a href="#"><i class="ti-instagram"></i></a>
                               <a href="#"><i class="ti-twitter"></i></a>
                               <a href="#"><i class="ti-facebook"></i></a>
                               <a href="#"><i class="ti-pinterest"></i></a>
                               <p>enrico@hotel.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img"> <img src="img/team/6.jpg" alt=""> </div>
                    <div class="info">
                        <h6>Victoria Dan</h6>
                        <p>Meetings and Events Manager</p>
                        <div class="social valign">
                            <div class="full-width">
                               <a href="#"><i class="ti-instagram"></i></a>
                               <a href="#"><i class="ti-twitter"></i></a>
                               <a href="#"><i class="ti-facebook"></i></a>
                               <a href="#"><i class="ti-pinterest"></i></a>
                               <p>victoria@hotel.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('layouts.components.testimonials-guests-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
    <script>

    </script>

   
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARVEL PROJECTS\ZamindarHotel\resources\views/about.blade.php ENDPATH**/ ?>