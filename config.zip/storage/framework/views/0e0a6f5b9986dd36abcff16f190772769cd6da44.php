

<!-- Clients -->
<section class="clients">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
            <div class="owl-carousel owl-theme">
                <div class="clients-logo">
                    <a href="#0"><img src="img/logo.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/logo.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/logo.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/logo.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/logo.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/logo.png" alt=""></a>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH H:\LARVEL PROJECTS\Static Website Blade Templating in Laravel Components File Structure - ZamindarHotel\resources\views/layouts/components/clients-logo-index.blade.php ENDPATH**/ ?>