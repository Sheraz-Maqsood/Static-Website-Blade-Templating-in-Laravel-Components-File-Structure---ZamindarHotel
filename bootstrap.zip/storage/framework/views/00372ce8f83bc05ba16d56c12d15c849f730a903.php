

<!-- Clients -->
<section class="clients">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
            <div class="owl-carousel owl-theme">
                <div class="clients-logo">
                    <a href="#0"><img src="img/clients/1.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/clients/2.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/clients/3.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/clients/4.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/clients/5.png" alt=""></a>
                </div>
                <div class="clients-logo">
                    <a href="#0"><img src="img/clients/6.png" alt=""></a>
                </div>
            </div>
            </div>
        </div>
    </div>
</section><?php /**PATH H:\LARVEL PROJECTS\ZamindarHotel\resources\views/layouts/components/clients-logo-index.blade.php ENDPATH**/ ?>