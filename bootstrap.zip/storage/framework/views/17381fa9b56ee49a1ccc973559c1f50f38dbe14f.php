<!-- Team -->
<section class="team section-padding bg-darkblack">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-subtitle">Professionals</div>
                <div class="section-title">Meet The Team</div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 owl-carousel owl-theme">
                <div class="item">
                    <div class="img"> <img src="img/team/7.JPG" alt=""> </div>
                    <div class="info">
                        <h6>Sadat Ajmal </h6>
                        <p>Chief Executive Officer</p>
                        <div class="social valign">
                            <div class="full-width">
                               
                               <p>sadatajmal@theheritagegp.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img">
                    <img src="img/team/7.JPG" alt=""> </div>
                    <div class="info">
                        <h6>Gohar Cheema</h6>
                        <p>Chief Operating Officer</p>
                        <div class="social valign">
                            <div class="full-width">
                                
                                <p>goharcheema@theheritagegp.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="img"> <img src="img/team/8.jpeg" alt=""> </div>
                    <div class="info">
                        <h6>Malik Aadil Maqsood</h6>
                        <p>Hotel & Restaurant Manager</p>
                        <div class="social valign">
                            <div class="social valign">
                                <div class="full-width">
                                   
                                   <p>aadilmaqsood@theheritagegp.com</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php /**PATH H:\LARVEL PROJECTS\Static Website Blade Templating in Laravel Components File Structure - ZamindarHotel\resources\views/layouts/components/team-about.blade.php ENDPATH**/ ?>