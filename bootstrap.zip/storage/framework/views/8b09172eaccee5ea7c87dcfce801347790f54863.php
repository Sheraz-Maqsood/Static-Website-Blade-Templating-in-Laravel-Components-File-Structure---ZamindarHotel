 <!-- jQuery -->
 <script src="js/jquery-3.6.3.min.js"></script>
 <script src="js/jquery-migrate-3.0.0.min.js"></script>
 <script src="js/modernizr-2.6.2.min.js"></script>
 <script src="js/imagesloaded.pkgd.min.js"></script>
 <script src="js/jquery.isotope.v3.0.2.js"></script>
 <script src="js/pace.js"></script>
 <script src="js/popper.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <script src="js/scrollIt.min.js"></script>
 <script src="js/jquery.waypoints.min.js"></script>
 <script src="js/owl.carousel.min.js"></script>
 <script src="js/jquery.stellar.min.js"></script>
 <script src="js/jquery.magnific-popup.js"></script>
 <script src="js/YouTubePopUp.js"></script>
 <script src="js/select2.js"></script>
 <script src="js/datepicker.js"></script>
 <script src="js/smooth-scroll.min.js"></script>
 <script src="js/custom.js"></script>
<?php /**PATH H:\LARVEL PROJECTS\Static Website Blade Templating in Laravel Components File Structure - ZamindarHotel\resources\views/layouts/partials/scripts.blade.php ENDPATH**/ ?>