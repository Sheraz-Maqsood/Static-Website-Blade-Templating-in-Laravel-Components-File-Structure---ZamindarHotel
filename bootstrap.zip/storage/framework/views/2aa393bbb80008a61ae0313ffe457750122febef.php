<!DOCTYPE html>
<html lang="zxx">

<!-- zamindarhotel.pears.info/demo/html/cappa/demo6-dark/coming-soon.html, Sun, 13 Aug 2023 10:10:30 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>The Cappa Luxury Hotel</title>
    <link rel="shortcut icon" href="img/favicon.png" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow&amp;family=Barlow+Condensed&amp;family=Gilda+Display&amp;display=swap">
    <link rel="stylesheet" href="css/plugins.css" />
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Comming soon -->
    <section class="comming section-padding">
        <div class="v-middle">
            <div class="container">
                <div class="row text-center mb-30">
                    <div class="col-md-12">
                        <h2>Coming Soon!</h2>
                        <h6>Our website is under construction</h6>
                    </div>
                </div>
                <div class="row text-center mb-30">
                    <div class="col-6 offset-md-2 col-md-2">
                        <div class="item">
                            <div class="down">
                                <h3 id="days">00</h3>
                            </div>
                            <div class="item-info">
                                <h6 class="mb-0">Days</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="item">
                            <div class="down">
                                <h3 id="hours">00</h3>
                            </div>
                            <div class="item-info">
                                <h6 class="mb-0">Hours</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="item">
                            <div class="down">
                                <h3 id="minutes">00</h3>
                            </div>
                            <div class="item-info">
                                <h6 class="mb-0">Minutes</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-2">
                        <div class="item">
                            <div class="down">
                                <h3 id="seconds">00</h3>
                            </div>
                            <div class="item-info">
                                <h6 class="mb-0">Seconds</h6>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row text-center">
                    <div class="go-back col-md-12">
                        <a href='/'> <span><i class="ti-arrow-left" aria-hidden="true"></i></span>&nbsp; Back To Home </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- jQuery -->
    <script src="js/jquery-3.6.3.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.min.js"></script>
    <script src="js/modernizr-2.6.2.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/jquery.isotope.v3.0.2.js"></script>
    <script src="js/pace.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scrollIt.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/YouTubePopUp.js"></script>
    <script src="js/select2.js"></script>
    <script src="js/datepicker.js"></script>
    <script src="js/smooth-scroll.min.js"></script>
    <script src="js/custom.js"></script>
    <script type="text/javascript">
        function countdown() {
            var now = new Date();
            var eventDate = new Date(2023, 6, 6);
            var currentTiime = now.getTime();
            var eventTime = eventDate.getTime();
            var remTime = eventTime - currentTiime;
            var s = Math.floor(remTime / 1000);
            var m = Math.floor(s / 60);
            var h = Math.floor(m / 60);
            var d = Math.floor(h / 24);
            h %= 24;
            m %= 60;
            s %= 60;
            h = (h < 10) ? "0" + h : h;
            m = (m < 10) ? "0" + m : m;
            s = (s < 10) ? "0" + s : s;
            document.getElementById("days").textContent = d;
            document.getElementById("days").innerText = d;
            document.getElementById("hours").textContent = h;
            document.getElementById("minutes").textContent = m;
            document.getElementById("seconds").textContent = s;
            setTimeout(countdown, 1000);
        }
        countdown();

    </script>
</body>

<!-- zamindarhotel.pears.info/demo/html/cappa/demo6-dark/coming-soon.html, Sun, 13 Aug 2023 10:10:30 GMT -->
</html>
<?php /**PATH H:\LARVEL PROJECTS\ZamindarHotel\resources\views/coming-soon.blade.php ENDPATH**/ ?>